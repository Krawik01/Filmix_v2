package pl.wasko.filmixbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmixBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(FilmixBackendApplication.class, args);
    }

}


