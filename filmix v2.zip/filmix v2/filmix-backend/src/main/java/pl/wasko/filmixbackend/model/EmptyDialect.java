package pl.wasko.filmixbackend.model;

public class EmptyDialect extends org.hibernate.dialect.Dialect {
}
