package pl.wasko.filmixbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pl.wasko.filmixbackend.model.Image;

@Repository
public interface ImageRepository extends JpaRepository<Image, Long> {

}
