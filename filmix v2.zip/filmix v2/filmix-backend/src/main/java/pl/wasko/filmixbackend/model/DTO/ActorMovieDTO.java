package pl.wasko.filmixbackend.model.DTO;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ActorMovieDTO {

    private Long actorId;

    private String roleName;

}

