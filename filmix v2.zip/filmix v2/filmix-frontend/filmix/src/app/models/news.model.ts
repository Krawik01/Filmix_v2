
import {VideoContent} from './video-content.model'

 
  
  export interface News {
    id: number;
    movie: VideoContent;
    content: string;
  }
  